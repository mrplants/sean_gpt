from sqlmodel import Field, SQLModel
from typing import Optional
from uuid import UUID

class AI(SQLModel, table=True):
    id: Optional[UUID] = Field(default=None, primary_key=True)
    name: str
