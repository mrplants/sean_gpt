from typing import Optional
from uuid import UUID

from sqlmodel import Field, SQLModel

class User(SQLModel):
    id: Optional[UUID] = Field(default=None, primary_key=True)
    email: str = Field(index=True, unique=True)

class AuthenticatedUser(User, table=True):
    hashed_password: str