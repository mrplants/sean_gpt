from fastapi import APIRouter

router = APIRouter(
    tags=["Chat Completion"],
)

