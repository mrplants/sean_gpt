from datetime import datetime
from typing import Optional
from uuid import UUID

from sqlmodel import Field, SQLModel

class Chat(SQLModel, table=True):
    id: Optional[UUID] = Field(default=None, primary_key=True)
    name: Optional[str] = None

class Message(SQLModel):
    role: str
    content: str

class ChatMessage(SQLModel):
    chat_id: UUID = Field(foreign_key="chat.id")
    chat_index: int
    timestamp: int = Field(default_factory=lambda: int(datetime.now().timestamp()), index=True)
    role: str
    content: str

class HumanChatMessage(ChatMessage, table=True):
    id: Optional[UUID] = Field(default=None, primary_key=True)
    sender_id: UUID = Field(foreign_key="user.id")

class AIChatMessage(ChatMessage, table=True):
    id: Optional[UUID] = Field(default=None, primary_key=True)
    ai_id: UUID = Field(foreign_key="ai.id")